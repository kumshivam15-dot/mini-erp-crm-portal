import bcrypt from "bcryptjs";
import cors from "cors";
import dotenv from "dotenv";
import express, { NextFunction, Request, Response } from "express";
import helmet from "helmet";
import jwt from "jsonwebtoken";
import morgan from "morgan";
import pg from "pg";
import { z, ZodError } from "zod";

dotenv.config();

const env = z.object({
  PORT: z.coerce.number().default(4000),
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(16),
  FRONTEND_ORIGIN: z.string().default("http://localhost:5173")
}).parse(process.env);

const pool = new pg.Pool({ connectionString: env.DATABASE_URL });
type Role = "Admin" | "Sales" | "Warehouse" | "Accounts";
type User = { id: string; name: string; email: string; role: Role };

declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

class HttpError extends Error {
  constructor(public statusCode: number, message: string, public details?: unknown) {
    super(message);
  }
}

const asyncHandler = (fn: (req: Request, res: Response) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => Promise.resolve(fn(req, res)).catch(next);

function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) throw new HttpError(401, "Missing bearer token");
  try {
    req.user = jwt.verify(header.slice(7), env.JWT_SECRET) as User;
    next();
  } catch {
    throw new HttpError(401, "Invalid or expired token");
  }
}

function requireRoles(...roles: Role[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) throw new HttpError(401, "Authentication required");
    if (!roles.includes(req.user.role)) throw new HttpError(403, "Permission denied for this role");
    next();
  };
}

function page(query: Request["query"]) {
  const pageNumber = Math.max(Number(query.page || 1), 1);
  const limit = Math.min(Math.max(Number(query.limit || 10), 1), 100);
  return { page: pageNumber, limit, offset: (pageNumber - 1) * limit };
}

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });
const customerSchema = z.object({
  customerName: z.string().min(2),
  mobileNumber: z.string().min(7),
  email: z.string().email(),
  businessName: z.string().min(2),
  gstNumber: z.string().optional().nullable(),
  customerType: z.enum(["Retail", "Wholesale", "Distributor"]),
  address: z.string().min(3),
  status: z.enum(["Lead", "Active", "Inactive"]),
  followUpDate: z.string().date().optional().nullable(),
  notes: z.string().optional().nullable()
});
const productSchema = z.object({
  productName: z.string().min(2),
  sku: z.string().min(2),
  category: z.string().min(2),
  unitPrice: z.coerce.number().nonnegative(),
  currentStock: z.coerce.number().int().nonnegative(),
  minimumStockAlertQuantity: z.coerce.number().int().nonnegative(),
  location: z.string().min(2)
});
const challanSchema = z.object({
  customerId: z.string().uuid(),
  status: z.enum(["Draft", "Confirmed"]).default("Draft"),
  items: z.array(z.object({ productId: z.string().uuid(), quantity: z.coerce.number().int().positive() })).min(1)
});

const app = express();
app.use(helmet());
app.use(cors({ origin: env.FRONTEND_ORIGIN, credentials: true }));
app.use(express.json());
app.use(morgan("dev"));

app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.post("/auth/login", asyncHandler(async (req, res) => {
  const input = loginSchema.parse(req.body);
  const { rows } = await pool.query("SELECT id,name,email,password_hash,role FROM users WHERE email=$1", [input.email.toLowerCase()]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(input.password, user.password_hash))) throw new HttpError(401, "Invalid email or password");
  const payload = { id: user.id, name: user.name, email: user.email, role: user.role };
  res.json({ token: jwt.sign(payload, env.JWT_SECRET, { expiresIn: "8h" }), user: payload });
}));

app.get("/dashboard/summary", requireAuth, asyncHandler(async (_req, res) => {
  const [customers, products, challans, lowStock] = await Promise.all([
    pool.query("SELECT COUNT(*)::int AS count FROM customers"),
    pool.query("SELECT COUNT(*)::int AS count FROM products"),
    pool.query("SELECT COUNT(*)::int AS count FROM challans WHERE status='Confirmed'"),
    pool.query("SELECT COUNT(*)::int AS count FROM products WHERE current_stock <= minimum_stock_alert_quantity")
  ]);
  res.json({
    customers: customers.rows[0].count,
    products: products.rows[0].count,
    confirmedChallans: challans.rows[0].count,
    lowStockProducts: lowStock.rows[0].count
  });
}));

app.get("/customers", requireAuth, asyncHandler(async (req, res) => {
  const { page: pageNumber, limit, offset } = page(req.query);
  const search = String(req.query.search || "").trim();
  const params: unknown[] = search ? [`%${search}%`] : [];
  const where = search ? "WHERE customer_name ILIKE $1 OR business_name ILIKE $1 OR mobile_number ILIKE $1 OR email ILIKE $1" : "";
  const count = await pool.query(`SELECT COUNT(*)::int AS total FROM customers ${where}`, params);
  params.push(limit, offset);
  const { rows } = await pool.query(
    `SELECT id, customer_name AS "customerName", mobile_number AS "mobileNumber", email, business_name AS "businessName",
      gst_number AS "gstNumber", customer_type AS "customerType", address, status, follow_up_date AS "followUpDate", notes
     FROM customers ${where} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  res.json({ data: rows, page: pageNumber, limit, total: count.rows[0].total });
}));

app.post("/customers", requireAuth, requireRoles("Admin", "Sales"), asyncHandler(async (req, res) => {
  const input = customerSchema.parse(req.body);
  const { rows } = await pool.query(
    `INSERT INTO customers (customer_name,mobile_number,email,business_name,gst_number,customer_type,address,status,follow_up_date,notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     RETURNING id, customer_name AS "customerName", mobile_number AS "mobileNumber", email, business_name AS "businessName",
      gst_number AS "gstNumber", customer_type AS "customerType", address, status, follow_up_date AS "followUpDate", notes`,
    [input.customerName, input.mobileNumber, input.email, input.businessName, input.gstNumber || null, input.customerType, input.address, input.status, input.followUpDate || null, input.notes || null]
  );
  res.status(201).json(rows[0]);
}));

app.put("/customers/:id", requireAuth, requireRoles("Admin", "Sales"), asyncHandler(async (req, res) => {
  const input = customerSchema.parse(req.body);
  const { rows } = await pool.query(
    `UPDATE customers SET customer_name=$1,mobile_number=$2,email=$3,business_name=$4,gst_number=$5,customer_type=$6,address=$7,status=$8,follow_up_date=$9,notes=$10,updated_at=now()
     WHERE id=$11 RETURNING id, customer_name AS "customerName", mobile_number AS "mobileNumber", email, business_name AS "businessName", status`,
    [input.customerName, input.mobileNumber, input.email, input.businessName, input.gstNumber || null, input.customerType, input.address, input.status, input.followUpDate || null, input.notes || null, req.params.id]
  );
  if (!rows[0]) throw new HttpError(404, "Customer not found");
  res.json(rows[0]);
}));

app.get("/customers/:id", requireAuth, asyncHandler(async (req, res) => {
  const customer = await pool.query(
    `SELECT id, customer_name AS "customerName", mobile_number AS "mobileNumber", email, business_name AS "businessName", gst_number AS "gstNumber",
      customer_type AS "customerType", address, status, follow_up_date AS "followUpDate", notes FROM customers WHERE id=$1`,
    [req.params.id]
  );
  if (!customer.rows[0]) throw new HttpError(404, "Customer not found");
  const followups = await pool.query(
    `SELECT f.id, f.note, f.created_at AS "createdAt", u.name AS "createdBy" FROM customer_followups f JOIN users u ON u.id=f.created_by WHERE f.customer_id=$1 ORDER BY f.created_at DESC`,
    [req.params.id]
  );
  res.json({ ...customer.rows[0], followups: followups.rows });
}));

app.post("/customers/:id/followups", requireAuth, requireRoles("Admin", "Sales"), asyncHandler(async (req, res) => {
  const input = z.object({ note: z.string().min(2) }).parse(req.body);
  const { rows } = await pool.query(
    "INSERT INTO customer_followups (customer_id,note,created_by) VALUES ($1,$2,$3) RETURNING id,note,created_at AS \"createdAt\"",
    [req.params.id, input.note, req.user!.id]
  );
  res.status(201).json(rows[0]);
}));

app.get("/products", requireAuth, asyncHandler(async (req, res) => {
  const { page: pageNumber, limit, offset } = page(req.query);
  const search = String(req.query.search || "").trim();
  const params: unknown[] = search ? [`%${search}%`] : [];
  const where = search ? "WHERE product_name ILIKE $1 OR sku ILIKE $1 OR category ILIKE $1" : "";
  const count = await pool.query(`SELECT COUNT(*)::int AS total FROM products ${where}`, params);
  params.push(limit, offset);
  const { rows } = await pool.query(
    `SELECT id, product_name AS "productName", sku, category, unit_price AS "unitPrice", current_stock AS "currentStock",
      minimum_stock_alert_quantity AS "minimumStockAlertQuantity", location FROM products ${where} ORDER BY product_name LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params
  );
  res.json({ data: rows, page: pageNumber, limit, total: count.rows[0].total });
}));

app.post("/products", requireAuth, requireRoles("Admin", "Warehouse"), asyncHandler(async (req, res) => {
  const input = productSchema.parse(req.body);
  const { rows } = await pool.query(
    `INSERT INTO products (product_name,sku,category,unit_price,current_stock,minimum_stock_alert_quantity,location)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id, product_name AS "productName", sku, category, unit_price AS "unitPrice", current_stock AS "currentStock", minimum_stock_alert_quantity AS "minimumStockAlertQuantity", location`,
    [input.productName, input.sku, input.category, input.unitPrice, input.currentStock, input.minimumStockAlertQuantity, input.location]
  );
  res.status(201).json(rows[0]);
}));

app.put("/products/:id", requireAuth, requireRoles("Admin", "Warehouse"), asyncHandler(async (req, res) => {
  const input = productSchema.parse(req.body);
  const { rows } = await pool.query(
    `UPDATE products SET product_name=$1,sku=$2,category=$3,unit_price=$4,current_stock=$5,minimum_stock_alert_quantity=$6,location=$7,updated_at=now()
     WHERE id=$8 RETURNING id, product_name AS "productName", sku, category, unit_price AS "unitPrice", current_stock AS "currentStock", location`,
    [input.productName, input.sku, input.category, input.unitPrice, input.currentStock, input.minimumStockAlertQuantity, input.location, req.params.id]
  );
  if (!rows[0]) throw new HttpError(404, "Product not found");
  res.json(rows[0]);
}));

app.post("/products/:id/movements", requireAuth, requireRoles("Admin", "Warehouse"), asyncHandler(async (req, res) => {
  const input = z.object({ quantityChanged: z.coerce.number().int().positive(), movementType: z.enum(["IN", "OUT"]), reason: z.string().min(2) }).parse(req.body);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const product = await client.query("SELECT current_stock FROM products WHERE id=$1 FOR UPDATE", [req.params.id]);
    if (!product.rows[0]) throw new HttpError(404, "Product not found");
    const next = input.movementType === "IN" ? Number(product.rows[0].current_stock) + input.quantityChanged : Number(product.rows[0].current_stock) - input.quantityChanged;
    if (next < 0) throw new HttpError(409, "Stock movement would make stock negative");
    await client.query("UPDATE products SET current_stock=$1,updated_at=now() WHERE id=$2", [next, req.params.id]);
    const movement = await client.query(
      `INSERT INTO stock_movements (product_id,quantity_changed,movement_type,reason,created_by) VALUES ($1,$2,$3,$4,$5)
       RETURNING id, quantity_changed AS "quantityChanged", movement_type AS "movementType", reason, created_at AS "createdAt"`,
      [req.params.id, input.quantityChanged, input.movementType, input.reason, req.user!.id]
    );
    await client.query("COMMIT");
    res.status(201).json({ ...movement.rows[0], currentStock: next });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/products/movements/log", requireAuth, asyncHandler(async (_req, res) => {
  const { rows } = await pool.query(
    `SELECT m.id, p.product_name AS "productName", p.sku, m.quantity_changed AS "quantityChanged", m.movement_type AS "movementType",
      m.reason, u.name AS "createdBy", m.created_at AS "createdAt" FROM stock_movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.created_by ORDER BY m.created_at DESC LIMIT 100`
  );
  res.json(rows);
}));

async function nextChallanNumber() {
  const year = new Date().getFullYear();
  const { rows } = await pool.query("SELECT COUNT(*)::int + 1 AS next FROM challans WHERE challan_number LIKE $1", [`SC-${year}-%`]);
  return `SC-${year}-${String(rows[0].next).padStart(5, "0")}`;
}

app.get("/challans", requireAuth, asyncHandler(async (req, res) => {
  const { page: pageNumber, limit, offset } = page(req.query);
  const { rows } = await pool.query(
    `SELECT c.id, c.challan_number AS "challanNumber", cu.business_name AS "businessName", c.total_quantity AS "totalQuantity",
      c.status, c.created_at AS "createdAt" FROM challans c JOIN customers cu ON cu.id=c.customer_id ORDER BY c.created_at DESC LIMIT $1 OFFSET $2`,
    [limit, offset]
  );
  const count = await pool.query("SELECT COUNT(*)::int AS total FROM challans");
  res.json({ data: rows, page: pageNumber, limit, total: count.rows[0].total });
}));

app.post("/challans", requireAuth, requireRoles("Admin", "Sales"), asyncHandler(async (req, res) => {
  const input = challanSchema.parse(req.body);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const challanNumber = await nextChallanNumber();
    const ids = input.items.map((item) => item.productId);
    const products = await client.query("SELECT id, product_name, sku, category, unit_price, current_stock FROM products WHERE id=ANY($1::uuid[]) FOR UPDATE", [ids]);
    const map = new Map(products.rows.map((row) => [row.id, row]));
    for (const item of input.items) {
      const product = map.get(item.productId);
      if (!product) throw new HttpError(400, "Product not found", { productId: item.productId });
      if (input.status === "Confirmed" && Number(product.current_stock) < item.quantity) {
        throw new HttpError(409, `Insufficient stock for ${product.product_name}`, { available: Number(product.current_stock), requested: item.quantity });
      }
    }
    const total = input.items.reduce((sum, item) => sum + item.quantity, 0);
    const challan = await client.query(
      `INSERT INTO challans (challan_number,customer_id,total_quantity,status,created_by,confirmed_at)
       VALUES ($1,$2,$3,$4,$5,CASE WHEN $4='Confirmed' THEN now() ELSE NULL END) RETURNING id, challan_number AS "challanNumber", total_quantity AS "totalQuantity", status`,
      [challanNumber, input.customerId, total, input.status, req.user!.id]
    );
    const createdItems = [];
    for (const item of input.items) {
      const product = map.get(item.productId);
      const lineTotal = Number(product.unit_price) * item.quantity;
      const inserted = await client.query(
        `INSERT INTO challan_items (challan_id,product_id,product_name,sku,category,unit_price,quantity,line_total)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, product_name AS "productName", sku, unit_price AS "unitPrice", quantity, line_total AS "lineTotal"`,
        [challan.rows[0].id, item.productId, product.product_name, product.sku, product.category, product.unit_price, item.quantity, lineTotal]
      );
      createdItems.push(inserted.rows[0]);
      if (input.status === "Confirmed") {
        await client.query("UPDATE products SET current_stock=current_stock-$1,updated_at=now() WHERE id=$2", [item.quantity, item.productId]);
        await client.query("INSERT INTO stock_movements (product_id,quantity_changed,movement_type,reason,created_by) VALUES ($1,$2,'OUT',$3,$4)", [item.productId, item.quantity, `Sales challan ${challanNumber}`, req.user!.id]);
      }
    }
    await client.query("COMMIT");
    res.status(201).json({ ...challan.rows[0], items: createdItems });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/challans/:id", requireAuth, asyncHandler(async (req, res) => {
  const challan = await pool.query(
    `SELECT c.id, c.challan_number AS "challanNumber", c.total_quantity AS "totalQuantity", c.status, c.created_at AS "createdAt",
      cu.customer_name AS "customerName", cu.business_name AS "businessName" FROM challans c JOIN customers cu ON cu.id=c.customer_id WHERE c.id=$1`,
    [req.params.id]
  );
  if (!challan.rows[0]) throw new HttpError(404, "Challan not found");
  const items = await pool.query("SELECT product_name AS \"productName\", sku, unit_price AS \"unitPrice\", quantity, line_total AS \"lineTotal\" FROM challan_items WHERE challan_id=$1", [req.params.id]);
  res.json({ ...challan.rows[0], items: items.rows });
}));

app.patch("/challans/:id/confirm", requireAuth, requireRoles("Admin", "Sales"), asyncHandler(async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const challan = await client.query("SELECT id,challan_number,status FROM challans WHERE id=$1 FOR UPDATE", [req.params.id]);
    if (!challan.rows[0]) throw new HttpError(404, "Challan not found");
    if (challan.rows[0].status !== "Draft") throw new HttpError(409, "Only draft challans can be confirmed");
    const items = await client.query("SELECT product_id,product_name,quantity FROM challan_items WHERE challan_id=$1", [req.params.id]);
    for (const item of items.rows) {
      const product = await client.query("SELECT current_stock FROM products WHERE id=$1 FOR UPDATE", [item.product_id]);
      if (!product.rows[0] || Number(product.rows[0].current_stock) < Number(item.quantity)) throw new HttpError(409, `Insufficient stock for ${item.product_name}`);
    }
    for (const item of items.rows) {
      await client.query("UPDATE products SET current_stock=current_stock-$1,updated_at=now() WHERE id=$2", [item.quantity, item.product_id]);
      await client.query("INSERT INTO stock_movements (product_id,quantity_changed,movement_type,reason,created_by) VALUES ($1,$2,'OUT',$3,$4)", [item.product_id, item.quantity, `Sales challan ${challan.rows[0].challan_number}`, req.user!.id]);
    }
    await client.query("UPDATE challans SET status='Confirmed',confirmed_at=now() WHERE id=$1", [req.params.id]);
    await client.query("COMMIT");
    res.json({ message: "Challan confirmed" });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}));

app.use((req, _res, next) => next(new HttpError(404, `Route not found: ${req.method} ${req.path}`)));
app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof ZodError) return res.status(400).json({ message: "Validation failed", details: error.flatten() });
  if (error instanceof HttpError) return res.status(error.statusCode).json({ message: error.message, details: error.details });
  console.error(error);
  return res.status(500).json({ message: "Internal server error" });
});

app.listen(env.PORT, () => console.log(`API listening on http://localhost:${env.PORT}`));
