import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import pg from "pg";

dotenv.config();
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

async function main() {
  await pool.query(await readFile(resolve("backend/schema.sql"), "utf8"));
  const passwordHash = await bcrypt.hash("Password@123", 10);
  for (const [name, email, role] of [
    ["Admin User", "admin@example.com", "Admin"],
    ["Sales User", "sales@example.com", "Sales"],
    ["Warehouse User", "warehouse@example.com", "Warehouse"],
    ["Accounts User", "accounts@example.com", "Accounts"]
  ]) {
    await pool.query(
      `INSERT INTO users (name,email,password_hash,role) VALUES ($1,$2,$3,$4)
       ON CONFLICT (email) DO UPDATE SET password_hash=EXCLUDED.password_hash, role=EXCLUDED.role`,
      [name, email, passwordHash, role]
    );
  }
  await pool.query(`
    INSERT INTO customers (customer_name,mobile_number,email,business_name,gst_number,customer_type,address,status,follow_up_date,notes) VALUES
    ('Riya Sharma','9876543210','riya@freshmart.example','FreshMart Traders','27ABCDE1234F1Z5','Wholesale','Andheri East, Mumbai','Active',CURRENT_DATE + 3,'Prefers morning follow-ups'),
    ('Karan Mehta','9811112233','karan@cityretail.example','City Retail Hub',NULL,'Retail','Navrangpura, Ahmedabad','Lead',CURRENT_DATE + 1,'Interested in monthly supply')
    ON CONFLICT DO NOTHING;
  `);
  await pool.query(`
    INSERT INTO products (product_name,sku,category,unit_price,current_stock,minimum_stock_alert_quantity,location) VALUES
    ('Premium Rice 25kg','RICE-25-PREM','Grains',1450,120,25,'Warehouse A - Rack 1'),
    ('Sunflower Oil 15L','OIL-15-SUN','Oils',1850,48,15,'Warehouse A - Rack 4'),
    ('Organic Sugar 10kg','SUGAR-10-ORG','Staples',720,8,20,'Warehouse B - Rack 2')
    ON CONFLICT (sku) DO NOTHING;
  `);
  console.log("Seed complete. Password for every role: Password@123");
  await pool.end();
}

main().catch(async (error) => {
  console.error(error);
  await pool.end();
  process.exit(1);
});
