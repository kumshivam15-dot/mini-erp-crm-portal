import React, { FormEvent, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { Boxes, ClipboardList, LayoutDashboard, LogOut, PackagePlus, Plus, Search, UsersRound } from "lucide-react";
import "./style.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:4000";
type Role = "Admin" | "Sales" | "Warehouse" | "Accounts";
type User = { id: string; name: string; email: string; role: Role };
type Page = "dashboard" | "customers" | "inventory" | "challans";
type Customer = { id: string; customerName: string; mobileNumber: string; email: string; businessName: string; customerType: string; address: string; status: string };
type Product = { id: string; productName: string; sku: string; category: string; unitPrice: number; currentStock: number; minimumStockAlertQuantity: number; location: string };
type Challan = { id: string; challanNumber: string; businessName: string; totalQuantity: number; status: string; createdAt: string };

async function api<T>(path: string, options: RequestInit = {}) {
  const token = localStorage.getItem("token");
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers }
  });
  const body = await response.json().catch(() => null);
  if (!response.ok) throw new Error(body?.message || "Request failed");
  return body as T;
}

function Login({ onLogin }: { onLogin: (user: User) => void }) {
  const [email, setEmail] = useState("admin@example.com");
  const [password, setPassword] = useState("Password@123");
  const [error, setError] = useState("");
  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    try {
      const result = await api<{ token: string; user: User }>("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
      localStorage.setItem("token", result.token);
      localStorage.setItem("user", JSON.stringify(result.user));
      onLogin(result.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    }
  }
  return <main className="login"><section><PackagePlus size={34} /><h1>Mini ERP CRM</h1><p>Operations portal for customers, inventory, stock movements, and sales challans.</p><form onSubmit={submit}><input value={email} onChange={(e) => setEmail(e.target.value)} /><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />{error && <b className="bad">{error}</b>}<button className="primary">Login</button></form><small>admin, sales, warehouse, accounts @example.com. Password: Password@123</small></section></main>;
}

function Dashboard() {
  const [summary, setSummary] = useState<Record<string, number>>({});
  useEffect(() => { api<Record<string, number>>("/dashboard/summary").then(setSummary).catch(console.error); }, []);
  return <div className="content"><div className="metrics">{[
    ["Customers", summary.customers, UsersRound], ["Products", summary.products, Boxes], ["Confirmed challans", summary.confirmedChallans, ClipboardList], ["Low stock", summary.lowStockProducts, LayoutDashboard]
  ].map(([label, value, Icon]) => <article key={String(label)}><Icon size={22} /><span>{String(label)}</span><strong>{String(value ?? "-")}</strong></article>)}</div><div className="band"><h2>Business flow</h2><div className="flow"><span>Lead</span><span>Follow-up</span><span>Stock check</span><span>Confirmed challan</span><span>Stock reduced</span></div></div></div>;
}

function Customers({ user }: { user: User }) {
  const [rows, setRows] = useState<Customer[]>([]);
  const [search, setSearch] = useState("");
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({ customerName: "", mobileNumber: "", email: "", businessName: "", gstNumber: "", customerType: "Wholesale", address: "", status: "Lead", followUpDate: "", notes: "" });
  const canEdit = user.role === "Admin" || user.role === "Sales";
  async function load() { setRows((await api<{ data: Customer[] }>(`/customers?search=${encodeURIComponent(search)}&limit=100`)).data); }
  useEffect(() => { load().catch(console.error); }, []);
  async function submit(event: FormEvent) { event.preventDefault(); await api("/customers", { method: "POST", body: JSON.stringify(form) }); setMsg("Customer saved"); await load(); }
  return <div className="content grid"><section className="panel"><div className="tools"><label><Search size={16} /><input placeholder="Search customers" value={search} onChange={(e) => setSearch(e.target.value)} /></label><button onClick={load}>Search</button></div><Table headers={["Customer", "Business", "Type", "Status"]} rows={rows.map((r) => [<>{r.customerName}<small>{r.mobileNumber}</small></>, r.businessName, r.customerType, <span className={`pill ${r.status.toLowerCase()}`}>{r.status}</span>])} /></section>{canEdit && <section className="panel"><h2>Add customer</h2><form className="form" onSubmit={submit}>{["customerName","mobileNumber","email","businessName","gstNumber","address","followUpDate","notes"].map((key) => <input key={key} placeholder={key} value={(form as any)[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })} />)}<select value={form.customerType} onChange={(e) => setForm({ ...form, customerType: e.target.value })}><option>Retail</option><option>Wholesale</option><option>Distributor</option></select><select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}><option>Lead</option><option>Active</option><option>Inactive</option></select><button className="primary"><Plus size={16} /> Save</button>{msg && <b className="good">{msg}</b>}</form></section>}</div>;
}

function Inventory({ user }: { user: User }) {
  const [rows, setRows] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({ productName: "", sku: "", category: "", unitPrice: 0, currentStock: 0, minimumStockAlertQuantity: 0, location: "" });
  const canEdit = user.role === "Admin" || user.role === "Warehouse";
  async function load() { setRows((await api<{ data: Product[] }>(`/products?search=${encodeURIComponent(search)}&limit=100`)).data); }
  useEffect(() => { load().catch(console.error); }, []);
  async function submit(event: FormEvent) { event.preventDefault(); await api("/products", { method: "POST", body: JSON.stringify(form) }); setMsg("Product saved"); await load(); }
  async function move(row: Product, type: "IN" | "OUT") { const quantityChanged = Number(prompt(`Quantity ${type}`)); if (!quantityChanged) return; await api(`/products/${row.id}/movements`, { method: "POST", body: JSON.stringify({ quantityChanged, movementType: type, reason: "Manual stock adjustment" }) }); await load(); }
  return <div className="content grid"><section className="panel"><div className="tools"><label><Search size={16} /><input placeholder="Search inventory" value={search} onChange={(e) => setSearch(e.target.value)} /></label><button onClick={load}>Search</button></div><Table headers={["Product", "SKU", "Stock", "Location", ""]} rows={rows.map((r) => [<>{r.productName}<small>{r.category} - Rs {Number(r.unitPrice).toFixed(2)}</small></>, r.sku, <b className={r.currentStock <= r.minimumStockAlertQuantity ? "bad" : ""}>{r.currentStock}</b>, r.location, canEdit ? <span className="mini"><button onClick={() => move(r, "IN")}>IN</button><button onClick={() => move(r, "OUT")}>OUT</button></span> : ""])} /></section>{canEdit && <section className="panel"><h2>Add product</h2><form className="form" onSubmit={submit}>{Object.keys(form).map((key) => <input key={key} placeholder={key} type={typeof (form as any)[key] === "number" ? "number" : "text"} value={(form as any)[key]} onChange={(e) => setForm({ ...form, [key]: e.target.type === "number" ? Number(e.target.value) : e.target.value })} />)}<button className="primary"><Plus size={16} /> Save</button>{msg && <b className="good">{msg}</b>}</form></section>}</div>;
}

function Challans({ user }: { user: User }) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [rows, setRows] = useState<Challan[]>([]);
  const [customerId, setCustomerId] = useState("");
  const [status, setStatus] = useState("Draft");
  const [items, setItems] = useState([{ productId: "", quantity: 1 }]);
  const [msg, setMsg] = useState("");
  const canCreate = user.role === "Admin" || user.role === "Sales";
  async function load() { const [c, p, ch] = await Promise.all([api<{ data: Customer[] }>("/customers?limit=100"), api<{ data: Product[] }>("/products?limit=100"), api<{ data: Challan[] }>("/challans?limit=100")]); setCustomers(c.data); setProducts(p.data); setRows(ch.data); setCustomerId((old) => old || c.data[0]?.id || ""); }
  useEffect(() => { load().catch(console.error); }, []);
  async function submit(event: FormEvent) { event.preventDefault(); try { await api("/challans", { method: "POST", body: JSON.stringify({ customerId, status, items: items.filter((i) => i.productId) }) }); setMsg(status === "Confirmed" ? "Confirmed and stock reduced" : "Draft saved"); await load(); } catch (err) { setMsg(err instanceof Error ? err.message : "Could not save challan"); } }
  return <div className="content grid"><section className="panel"><h2>Sales challans</h2><Table headers={["No.", "Customer", "Qty", "Status", "Date"]} rows={rows.map((r) => [r.challanNumber, r.businessName, r.totalQuantity, <span className={`pill ${r.status.toLowerCase()}`}>{r.status}</span>, new Date(r.createdAt).toLocaleDateString()])} /></section>{canCreate && <section className="panel"><h2>Create challan</h2><form className="form" onSubmit={submit}><select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>{customers.map((c) => <option key={c.id} value={c.id}>{c.businessName}</option>)}</select><select value={status} onChange={(e) => setStatus(e.target.value)}><option>Draft</option><option>Confirmed</option></select>{items.map((item, index) => <div className="line" key={index}><select value={item.productId} onChange={(e) => { const next = [...items]; next[index] = { ...item, productId: e.target.value }; setItems(next); }}><option value="">Select product</option>{products.map((p) => <option key={p.id} value={p.id}>{p.productName} ({p.currentStock})</option>)}</select><input type="number" min={1} value={item.quantity} onChange={(e) => { const next = [...items]; next[index] = { ...item, quantity: Number(e.target.value) }; setItems(next); }} /></div>)}<button type="button" onClick={() => setItems([...items, { productId: "", quantity: 1 }])}>Add line</button><button className="primary">Save challan</button>{msg && <b className={msg.includes("Insufficient") ? "bad" : "good"}>{msg}</b>}</form></section>}</div>;
}

function Table({ headers, rows }: { headers: string[]; rows: React.ReactNode[][] }) {
  return <div className="table"><table><thead><tr>{headers.map((h) => <th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={index}>{row.map((cell, i) => <td key={i}>{cell}</td>)}</tr>)}</tbody></table></div>;
}

function App() {
  const [user, setUser] = useState<User | null>(() => JSON.parse(localStorage.getItem("user") || "null"));
  const [page, setPage] = useState<Page>("dashboard");
  if (!user) return <Login onLogin={setUser} />;
  const nav = [["dashboard", "Dashboard", LayoutDashboard], ["customers", "Customers", UsersRound], ["inventory", "Inventory", Boxes], ["challans", "Challans", ClipboardList]] as const;
  return <div className="shell"><aside><h1><PackagePlus /> Mini ERP</h1>{nav.map(([id, label, Icon]) => <button key={id} className={page === id ? "active" : ""} onClick={() => setPage(id)}><Icon size={17} />{label}</button>)}</aside><main><header><div><small>{user.role}</small><h2>{nav.find(([id]) => id === page)?.[1]}</h2></div><button onClick={() => { localStorage.clear(); setUser(null); }}><LogOut size={17} /> Logout</button></header>{page === "dashboard" && <Dashboard />}{page === "customers" && <Customers user={user} />}{page === "inventory" && <Inventory user={user} />}{page === "challans" && <Challans user={user} />}</main></div>;
}

createRoot(document.getElementById("root")!).render(<App />);
